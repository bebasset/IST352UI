
  # Bid Output Sheet 2 (Community)

  This is a code bundle for Bid Output Sheet 2 (Community). The original project is available at https://www.figma.com/design/bSATYP6KLFtHaEoK3ITIiW/Bid-Output-Sheet-2--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  