
  # Bid Output Sheet Design

  This is a code bundle for Bid Output Sheet Design. The original project is available at https://www.figma.com/design/q9kVIFGrIMUUWyW9gEhOgU/Bid-Output-Sheet-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  