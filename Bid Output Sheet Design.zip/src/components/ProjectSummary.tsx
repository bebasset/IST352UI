import { CheckCircle, Clock, XCircle } from 'lucide-react';

interface ProjectSummaryProps {
  title: string;
  description: string;
  status: 'approved' | 'pending' | 'declined';
}

export function ProjectSummary({ title, description, status }: ProjectSummaryProps) {
  const statusConfig = {
    approved: {
      color: 'bg-green-100 text-green-800 border-green-300',
      icon: CheckCircle,
      label: 'Approved'
    },
    pending: {
      color: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      icon: Clock,
      label: 'Pending'
    },
    declined: {
      color: 'bg-red-100 text-red-800 border-red-300',
      icon: XCircle,
      label: 'Declined'
    }
  };

  const config = statusConfig[status];
  const StatusIcon = config.icon;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full">
      <h2 className="text-gray-900 mb-4">Project Summary</h2>
      
      <div className="space-y-4">
        <div>
          <div className="text-sm text-gray-600 mb-1">Project Title</div>
          <div className="text-gray-900">{title}</div>
        </div>

        <div>
          <div className="text-sm text-gray-600 mb-1">Description</div>
          <p className="text-gray-700 text-sm leading-relaxed">{description}</p>
        </div>

        <div>
          <div className="text-sm text-gray-600 mb-2">Status</div>
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border ${config.color}`}>
            <StatusIcon className="w-5 h-5" />
            <span>{config.label}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
