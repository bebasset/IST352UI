import { Calendar, Clock, Flag } from 'lucide-react';

interface TimelineProps {
  designTime: string;
  projectDuration: string;
  eventDate: string;
  milestones: Array<{ name: string; date: string }>;
}

export function Timeline({ designTime, projectDuration, eventDate, milestones }: TimelineProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full">
      <h2 className="text-gray-900 mb-4">Timeline</h2>
      
      <div className="space-y-4">
        <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg border border-purple-200">
          <Clock className="w-5 h-5 text-purple-600" />
          <div>
            <div className="text-sm text-gray-600">Design Time</div>
            <div className="text-gray-900">{designTime}</div>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <Calendar className="w-5 h-5 text-blue-600" />
          <div>
            <div className="text-sm text-gray-600">Project Duration</div>
            <div className="text-gray-900">{projectDuration}</div>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
          <Flag className="w-5 h-5 text-green-600" />
          <div>
            <div className="text-sm text-gray-600">Event Date</div>
            <div className="text-gray-900">{eventDate}</div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="text-sm text-gray-600 mb-3">Key Milestones</div>
          <div className="space-y-2">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-700">{milestone.name}</span>
                </div>
                <span className="text-gray-600">{milestone.date}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
