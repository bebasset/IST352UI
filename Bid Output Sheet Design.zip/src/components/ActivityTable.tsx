import { useState } from 'react';
import { ChevronDown, ChevronUp, Sparkles, ArrowUpDown, MapPin, Users, Clock } from 'lucide-react';

interface Activity {
  id: number;
  name: string;
  cost: number;
  duration: string;
  location: string;
  attendees: number;
}

interface ActivityTableProps {
  activities: Activity[];
}

type SortField = 'name' | 'cost' | 'duration' | 'location' | 'attendees';
type SortDirection = 'asc' | 'desc';

export function ActivityTable({ activities }: ActivityTableProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const totalCost = activities.reduce((sum, activity) => sum + activity.cost, 0);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedActivities = [...activities].sort((a, b) => {
    let aValue = a[sortField];
    let bValue = b[sortField];

    if (typeof aValue === 'string') {
      aValue = aValue.toLowerCase();
      bValue = (bValue as string).toLowerCase();
    }

    if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-6 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-orange-600" />
          </div>
          <div className="text-left">
            <h3 className="text-gray-900">Activities & Events</h3>
            <p className="text-gray-600 text-sm">{activities.length} activities planned</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-gray-900">{formatCurrency(totalCost)}</span>
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-gray-600" />
          ) : (
            <ChevronDown className="w-5 h-5 text-gray-600" />
          )}
        </div>
      </button>

      {isExpanded && (
        <div className="border-t border-gray-200 overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-gray-700">
                  <button
                    onClick={() => handleSort('name')}
                    className="flex items-center gap-2 hover:text-gray-900"
                  >
                    Activity Name
                    <ArrowUpDown className="w-4 h-4" />
                  </button>
                </th>
                <th className="px-6 py-3 text-left text-gray-700">
                  <button
                    onClick={() => handleSort('cost')}
                    className="flex items-center gap-2 hover:text-gray-900"
                  >
                    Cost
                    <ArrowUpDown className="w-4 h-4" />
                  </button>
                </th>
                <th className="px-6 py-3 text-left text-gray-700">
                  <button
                    onClick={() => handleSort('duration')}
                    className="flex items-center gap-2 hover:text-gray-900"
                  >
                    Duration
                    <ArrowUpDown className="w-4 h-4" />
                  </button>
                </th>
                <th className="px-6 py-3 text-left text-gray-700">
                  <button
                    onClick={() => handleSort('location')}
                    className="flex items-center gap-2 hover:text-gray-900"
                  >
                    Location
                    <ArrowUpDown className="w-4 h-4" />
                  </button>
                </th>
                <th className="px-6 py-3 text-left text-gray-700">
                  <button
                    onClick={() => handleSort('attendees')}
                    className="flex items-center gap-2 hover:text-gray-900"
                  >
                    Attendees
                    <ArrowUpDown className="w-4 h-4" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {sortedActivities.map((activity) => (
                <tr key={activity.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-gray-900">
                    {activity.name}
                  </td>
                  <td className="px-6 py-4 text-gray-900">
                    {formatCurrency(activity.cost)}
                  </td>
                  <td className="px-6 py-4 text-gray-700">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      {activity.duration}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-700">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      {activity.location}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-700">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-gray-500" />
                      {activity.attendees}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
