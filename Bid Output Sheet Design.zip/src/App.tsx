import { BidHeader } from './components/BidHeader';
import { ProjectSummary } from './components/ProjectSummary';
import { CostBreakdown } from './components/CostBreakdown';
import { Timeline } from './components/Timeline';
import { HotelDetails } from './components/HotelDetails';
import { ActivityTable } from './components/ActivityTable';
import { DesignerInfo } from './components/DesignerInfo';
import { BidFooter } from './components/BidFooter';
import { Toaster } from 'sonner@2.0.3';

// Mock data for the bid
const bidData = {
  bidNumber: "BID-2024-1847",
  date: "December 2, 2025",
  client: {
    company: "Acme Corporation",
    contact: "John Smith",
    email: "john.smith@acme.com",
    phone: "+1 (555) 123-4567"
  },
  project: {
    title: "Annual Sales Conference 2025",
    description: "Complete event planning and design services for the annual sales conference including venue coordination, graphic design materials, and team activities.",
    status: "pending" // approved, pending, declined
  },
  timeline: {
    designTime: "2 weeks",
    projectDuration: "6 weeks",
    eventDate: "February 15-17, 2025",
    milestones: [
      { name: "Design Approval", date: "Dec 16, 2025" },
      { name: "Venue Confirmation", date: "Jan 3, 2025" },
      { name: "Final Materials", date: "Feb 1, 2025" },
      { name: "Event Day", date: "Feb 15, 2025" }
    ]
  },
  designer: {
    name: "Sarah Johnson",
    role: "Lead Graphic Designer",
    email: "sarah.j@meetingmakers.com",
    estimate: 4500,
    deliverables: [
      "Event Logo & Branding",
      "Program Booklets (200 copies)",
      "Signage & Banners (5 pieces)",
      "Digital Presentations",
      "Name Badges & Materials"
    ]
  },
  hotel: {
    name: "Grand Plaza Hotel & Conference Center",
    rating: 4.5,
    phone: "+1 (555) 987-6543",
    location: "123 Conference Drive, Downtown District",
    roomRate: 189,
    nights: 2,
    rooms: 50,
    totalCost: 18900
  },
  activities: [
    {
      id: 1,
      name: "Welcome Reception & Networking",
      cost: 3500,
      duration: "2 hours",
      location: "Grand Plaza Hotel Ballroom",
      attendees: 100
    },
    {
      id: 2,
      name: "Team Building Workshop",
      cost: 2800,
      duration: "3 hours",
      location: "Conference Room A",
      attendees: 100
    },
    {
      id: 3,
      name: "Gala Dinner",
      cost: 8500,
      duration: "4 hours",
      location: "Grand Plaza Hotel Ballroom",
      attendees: 100
    },
    {
      id: 4,
      name: "Awards Ceremony",
      cost: 1500,
      duration: "1.5 hours",
      location: "Main Conference Hall",
      attendees: 100
    }
  ],
  projectManager: {
    name: "Michael Chen",
    title: "Senior Event Manager",
    email: "m.chen@meetingmakers.com",
    phone: "+1 (555) 234-5678"
  }
};

// Calculate totals
const designerTotal = bidData.designer.estimate;
const hotelTotal = bidData.hotel.totalCost;
const activitiesTotal = bidData.activities.reduce((sum, activity) => sum + activity.cost, 0);
const grandTotal = designerTotal + hotelTotal + activitiesTotal;

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />
      <div className="max-w-[1400px] mx-auto p-8">
        {/* Header */}
        <BidHeader 
          bidNumber={bidData.bidNumber}
          date={bidData.date}
          client={bidData.client}
        />

        {/* Main Content Area - Three Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          {/* Left: Project Summary */}
          <div className="lg:col-span-1">
            <ProjectSummary 
              title={bidData.project.title}
              description={bidData.project.description}
              status={bidData.project.status}
            />
          </div>

          {/* Center: Cost Breakdown */}
          <div className="lg:col-span-1">
            <CostBreakdown 
              designerCost={designerTotal}
              hotelCost={hotelTotal}
              activitiesCost={activitiesTotal}
              total={grandTotal}
            />
          </div>

          {/* Right: Timeline */}
          <div className="lg:col-span-1">
            <Timeline 
              designTime={bidData.timeline.designTime}
              projectDuration={bidData.timeline.projectDuration}
              eventDate={bidData.timeline.eventDate}
              milestones={bidData.timeline.milestones}
            />
          </div>
        </div>

        {/* Detailed Breakdown Section */}
        <div className="mt-8 space-y-6">
          {/* Designer Information */}
          <DesignerInfo designer={bidData.designer} />

          {/* Hotel Details */}
          <HotelDetails hotel={bidData.hotel} />

          {/* Activities Table */}
          <ActivityTable activities={bidData.activities} />
        </div>

        {/* Footer */}
        <BidFooter 
          total={grandTotal}
          projectManager={bidData.projectManager}
        />
      </div>
    </div>
  );
}